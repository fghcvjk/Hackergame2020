package cn.edu.ustc.lug.hack.miniminer;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Game instance per user
 */
public final class Game {

    public static Game refresh(User user, Game old) {
        return old != null && Instant.now().isBefore(old.expiration) ? old : new Game(user);
    }

    public JSONObject damage(Map<String, List<String>> params) {
        var material = Material.valueOf(params.get("material").get(0));
        var x = Integer.parseInt(params.get("x").get(0));
        var y = Integer.parseInt(params.get("y").get(0));
        var location = new Location(x, y);
        var result = new JSONObject();
        if (location.getMaterial().harderThan(material)) {
            this.waitFor(LONG_DURATION);
            result.put("dropped", Material.AIR.name()).put("flag", "");
        } else {
            this.waitFor(SHORT_DURATION);
            result.put("dropped", location.getMaterial().name());
            result.put("flag", location.getMaterial().flagOf(this.currentUser));
        }
        this.airLocations.add(location);
        return result;
    }

    public JSONObject reset(Map<String, List<String>> params) {
        this.baseSeed = (this.baseSeed << 3) | (BASE_SEED_RNG.nextInt() & 7);
        this.expiration = Instant.now().plus(EXPIRATION);

        this.airLocations.clear();
        this.airLocations.add(new Location(15, 15));
        this.airLocations.add(new Location(15, 16));
        this.airLocations.add(new Location(16, 15));
        this.airLocations.add(new Location(16, 16));

        return new JSONObject().put("user", this.currentUser).put("expiration", this.expiration);
    }

    public JSONObject state(Map<String, List<String>> params) {
        var x = Integer.parseInt(params.get("x").get(0));
        var y = Integer.parseInt(params.get("y").get(0));
        var minX = Math.floorDiv(x, 32) * 32;
        var minY = Math.floorDiv(y, 32) * 32;
        var materials = new JSONArray();
        for (var i = 0; i < 32; ++i) {
            var materialsPerLine = new JSONArray();
            for (var j = 0; j < 32; ++j) {
                materialsPerLine.put(new Location(minX + i, minY + j).getMaterial());
            }
            materials.put(materialsPerLine);
        }
        var min = new JSONArray().put(minX).put(minY);
        return new JSONObject().put("materials", materials).put("min", min);
    }

    private static final Duration SHORT_DURATION = Duration.ofSeconds(3);
    private static final Duration LONG_DURATION = Duration.ofSeconds(5);
    private static final Duration EXPIRATION = Duration.ofMinutes(30);

    private static final Random BASE_SEED_RNG = new SecureRandom();

    private final Set<Location> airLocations;
    private final User currentUser;
    private Instant expiration;
    private long baseSeed;

    private Game(User currentUser) {
        this.expiration = Instant.now().plus(EXPIRATION);
        this.baseSeed = BASE_SEED_RNG.nextLong();

        this.airLocations = ConcurrentHashMap.newKeySet();
        this.airLocations.add(new Location(15, 15));
        this.airLocations.add(new Location(15, 16));
        this.airLocations.add(new Location(16, 15));
        this.airLocations.add(new Location(16, 16));
        this.currentUser = currentUser;
    }

    private void waitFor(Duration duration) {
        try {
            Thread.sleep(duration.toMillis());
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private final class Location {
        private final int x;
        private final int y;

        private Location(int x, int y) {
            this.x = x;
            this.y = y;
        }

        private Material getMaterial() {
            var rng = new Random();
            var result = Material.AIR;
            if (!Game.this.airLocations.contains(this)) {
                for (var i = 1; i <= 5; ++i) {
                    var material = Material.values()[i];
                    var modular = material.size + material.size / 2;
                    var chunkX = Math.floorDiv(this.x, material.size);
                    var chunkY = Math.floorDiv(this.y, material.size);
                    var offsetX = Math.floorMod(this.x, material.size);
                    var offsetY = Math.floorMod(this.y, material.size);
                    rng.setSeed(Game.this.baseSeed ^ (i + 0x6E5D5AF15FA1280BL * chunkX + 0xE9716B1CE6339E6CL * chunkY));
                    for (var j = 0; j < material.count; ++j) {
                        var randomX = Math.floorMod(rng.nextInt() * ((1 << j) - 1) + chunkX + 1, modular);
                        var randomY = Math.floorMod(rng.nextInt() * ((1 << j) - 1) + chunkY + 1, modular);
                        if (randomX == offsetX && randomY == offsetY) {
                            result = material;
                        }
                    }
                }
            }
            return result;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Location && this.x == ((Location) o).x && this.y == ((Location) o).y;
        }

        @Override
        public int hashCode() {
            return 31 * this.x + this.y;
        }
    }

    private enum Material {
        AIR(1, 1), STONE(1, 1), IRON(32, 16), DIAMOND(32, 32), OBSIDIAN(16, 32), FLAG(2, 16777216);

        // ordinal: air 0, stone 1, iron 2, diamond 3, obsidian 4, flag 5

        private final int count;
        private final int size;

        Material(int count, int size) {
            this.count = count;
            this.size = size;
        }

        private boolean harderThan(Material other) {
            return this == FLAG || this.ordinal() > other.ordinal() + 1;
        }

        private String flagOf(User user) {
            return this == FLAG ? user.getFlag() : "";
        }
    }
}
