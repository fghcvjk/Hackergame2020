package cn.edu.ustc.lug.hack.miniminer;

import fi.iki.elonen.NanoHTTPD;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;

/**
 * Main class for http server
 */
public final class Main extends NanoHTTPD {

    public static void main(String[] args) throws Exception {
        var port = System.getenv().getOrDefault("MINIMINER_PORT", "8088");
        new Main(Integer.parseInt(port)).start(SOCKET_READ_TIMEOUT, false);
        System.out.println("Mini miner server started at localhost:" + port);
        Thread.currentThread().join(); // just make itself deadlocked for running forever
    }

    @Override
    public Response serve(IHTTPSession session) {
        switch (session.getMethod()) {
            case POST:
                return this.post(session);
            case GET:
                return this.get(session);
        }
        return this.error();
    }

    private static final String ERROR_RESPONSE = "SERVER INTERNAL ERROR: Not Found";

    private static final String MIME_JS = "application/javascript";
    private static final String MIME_JSON = "application/json";
    private static final String MIME_ZIP = "application/zip";
    private static final String MIME_ICO = "image/x-icon";
    private static final String MIME_PNG = "image/png";

    private final Map<User, Game> games;

    private Main(int port) {
        super(port);
        this.games = new ConcurrentHashMap<>();
    }

    private Response get(IHTTPSession session) {
        switch (session.getUri()) {
            case "/":
            case "/index.html":
                return this.file("/assets/miniminer/index.html", MIME_HTML);
            case "/textures/background.png":
            case "/textures/player.png":
            case "/textures/waiting0.png":
            case "/textures/waiting1.png":
            case "/textures/waiting2.png":
            case "/textures/waiting3.png":
            case "/textures/loading0.png":
            case "/textures/loading1.png":
            case "/textures/loading2.png":
            case "/textures/loading3.png":
            case "/textures/flag.png":
            case "/textures/obsidian.png":
            case "/textures/diamond.png":
            case "/textures/iron.png":
            case "/textures/stone.png":
            case "/textures/start.png":
                return this.file("/assets/miniminer" + session.getUri(), MIME_PNG);
            case "/favicon.ico":
                return this.file("/assets/miniminer" + session.getUri(), MIME_ICO);
            case "/astar.min.js":
            case "/index.min.js":
            case "/index.js":
                return this.file("/assets/miniminer" + session.getUri(), MIME_JS);
            case "/source.zip":
                return this.source(System.getenv("MINIMINER_SOURCE"));
            case "/api/state":
                return this.api(session, Game::state);
        }
        return this.error();
    }

    private Response post(IHTTPSession session) {
        switch (session.getUri()) {
            case "/api/state":
                return this.api(session, Game::state);
            case "/api/reset":
                return this.api(session, Game::reset);
            case "/api/damage":
                return this.api(session, Game::damage);
        }
        return this.error();
    }

    private Response api(IHTTPSession session, BiFunction<Game, Map<String, List<String>>, ?> handler) {
        try {
            var params = session.getParameters();
            var user = new User(params.get("token").get(0));
            var game = this.games.compute(user, Game::refresh);
            var response = handler.apply(game, params).toString();
            return newFixedLengthResponse(Response.Status.OK, MIME_JSON, response);
        } catch (Exception e) {
            return this.error();
        }
    }

    private Response error() {
        return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, ERROR_RESPONSE);
    }

    private Response file(String resource, String mimeType) {
        return newChunkedResponse(Response.Status.OK, mimeType, Main.class.getResourceAsStream(resource));
    }

    private Response source(String source) {
        try {
            return newChunkedResponse(Response.Status.OK, MIME_ZIP, Files.newInputStream(Path.of(source)));
        } catch (Exception e) {
            return this.error();
        }
    }
}
