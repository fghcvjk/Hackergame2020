package cn.edu.ustc.lug.hack.miniminer;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.Base64;

/**
 * Internal class for token verification
 */
public final class User {
    private static final Certificate CERTIFICATE;
    private static final MessageDigest DIGEST;

    private final short tokenHash;
    private final String id;

    static {
        try (var stream = User.class.getResourceAsStream("/assets/miniminer/cert.pem")) {
            CERTIFICATE = CertificateFactory.getInstance("X.509").generateCertificate(stream);
            DIGEST = MessageDigest.getInstance("SHA-256");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public User(String token) {
        this.id = this.check(token);
        var input = System.getenv("MINIMINER_SECRET") + ":" + token;
        this.tokenHash = ByteBuffer.wrap(DIGEST.digest(input.getBytes(StandardCharsets.UTF_8))).getShort();
    }

    private String check(String tokenString) {
        try {
            var user = tokenString.substring(0, tokenString.indexOf(':'));
            var sig = tokenString.substring(tokenString.indexOf(':') + 1);
            var userBytes = user.getBytes(StandardCharsets.UTF_8);
            var sigBytes = Base64.getDecoder().decode(sig);
            this.verify(userBytes, sigBytes);
            return user;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void verify(byte[] signedDataBytes, byte[] sigBytes) throws GeneralSecurityException {
        var signature = Signature.getInstance("SHA256withECDSA");
        signature.initVerify(CERTIFICATE);
        signature.update(signedDataBytes);
        if (!signature.verify(sigBytes)) {
            throw new SignatureException("invalid signature");
        }
    }

    public String getFlag() {
        return String.format("flag{%s_%04x}", System.getenv("MINIMINER_FLAG"), this.tokenHash);
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof User && ((User) o).id.equals(this.id);
    }

    @Override
    public int hashCode() {
        return this.id.hashCode();
    }

    @Override
    public String toString() {
        return this.id;
    }
}
